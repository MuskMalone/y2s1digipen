make
./shell.exe